export interface Card {
    imagePath: string;
    isFlipped: boolean;
}